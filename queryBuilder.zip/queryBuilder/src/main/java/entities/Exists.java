package entities;

public class Exists {
}
