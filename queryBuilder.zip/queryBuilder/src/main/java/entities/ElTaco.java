package entities;

import io.taco.sql.QueryMetamorph;

public class ElTaco {

    public static QueryMetamorph queryMetamorph = new QueryMetamorph();


    public Select select(){
        Select select = new Select();
        queryMetamorph.setSelect(select);
        return select;
    }

    public Select select (String parameter){
        Select select = new Select(parameter);
        queryMetamorph.setSelect(select);
        return select;
    }

    public Select select (String p1,String p2){
        Select select = new Select(p1,p2);
        queryMetamorph.setSelect(select);
        return select;
    }

    public Select select (String p1,String p2,String p3){
        Select select = new Select(p1,p2,p3);
        queryMetamorph.setSelect(select);
        return select;
    }

}
