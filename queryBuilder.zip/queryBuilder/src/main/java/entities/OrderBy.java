package entities;

public class OrderBy {

    boolean orderByColumn = false ;

    private static final String SQL_ORDER_BY = "ORDER BY ";

    @Override
    public String toString() {
        String orderBy = SQL_ORDER_BY;
        if (!orderByColumn){
            orderBy = orderBy.concat("NEWID()\n");
        }
        return orderBy;
    }

    public String getQuery(){
        return ElTaco.queryMetamorph.getQuery();
    }
}
