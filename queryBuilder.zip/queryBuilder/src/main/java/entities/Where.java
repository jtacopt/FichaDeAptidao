package entities;

import io.taco.sql.And;
import io.taco.sql.Condition;

public class Where {

    private static String SQL_WHERE = "WHERE ";

    public And qAnd ;

    private Condition qCondition ;

    public Where(Condition condition) {
        this.qCondition = condition;
    }

    public And and(Condition condition){
        And and = new And(condition);
        this.qAnd = and;
        return and;
    }

    public OrderBy orderBy () {
        OrderBy orderBy = new OrderBy();
        ElTaco.queryMetamorph.setOrderBy(orderBy);
        return orderBy;
    }

    public String getQuery(){
        return ElTaco.queryMetamorph.getQuery();
    }

    @Override
    public String toString() {
        return SQL_WHERE + qCondition.toString();
    }
}
