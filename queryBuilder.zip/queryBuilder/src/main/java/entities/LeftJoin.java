package entities;

public class LeftJoin {
}
