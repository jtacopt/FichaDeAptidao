package entities;

public class Union {
}
