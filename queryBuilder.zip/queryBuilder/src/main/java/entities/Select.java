package entities;

import io.taco.sql.From;

import java.util.ArrayList;
import java.util.List;

public class Select {

    private List<String> parameters = new ArrayList<>();

    public Select (){

    }

    public Select(String parameter) {
        parameters.add(parameter);
    }

    public Select(String p1, String p2) {
        parameters.add(p1);
        parameters.add(p2);
    }

    public Select(String p1, String p2, String p3) {
        parameters.add(p1);
        parameters.add(p2);
        parameters.add(p3);
    }

    public From from(Object object)  {
        From from = new From(object);
        ElTaco.queryMetamorph.setFrom(from);
        return from;
    }

    public List<String> getParameters() {
        return parameters;
    }

    @Override
    public String toString() {
        String select = "SELECT ";
        if (getParameters().isEmpty()) {
            select = select.concat("*");
        } else {
            select = select.concat(String.join(",",getParameters()));
        }
        select = select.concat("\n");
        return select;
    }
}