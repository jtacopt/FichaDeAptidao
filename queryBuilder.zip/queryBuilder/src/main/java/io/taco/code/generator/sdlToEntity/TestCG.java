package io.taco.code.generator.sdlToEntity;

import io.taco.metadata.Field;
import io.taco.metadata.Table;
import net.sourceforge.jenesis4java.*;

import java.util.Arrays;
import java.util.List;

public class TestCG {

    private VirtualMachine vm;

    private CompilationUnit unit;

    private PackageClass cls;

    private static final String TACO_DB_ENTITY = "io.taco.db.entity";

    private String tableName = "author";

    private Table table;

    String sdl = "CREATE TABLE library_books (\n" +
            "isbn CHAR(20)      PRIMARY KEY IQ UNIQUE (150000),\n" +
            "copyright_date     DATE,\n" +
            "title              CHAR(100),\n" +
            "author             CHAR(50)\n" +
            ")";

    private void getDataFromSDL(String sdl) {
        this.table = new Table();
        List<String> stringList = Arrays.asList(sdl.split("\\n"));
        for (String row : stringList) {
            String line = row.replaceAll("\\s+", "#");
            String[] parameters = line.split("#");
            if (row.toLowerCase().contains("table")) {
                table.setTableName(parameters[2]);
            } else if (parameters.length >= 2) {
                if (line.toLowerCase().contains("int")) {
                    table.getColumns().add(new Field(parameters[0], io.taco.metadata.enums.Type.Integer));
                } else {
                    table.getColumns().add(new Field(parameters[0], io.taco.metadata.enums.Type.String));
                }

            }
        }
    }

    private void setImportClasses(CompilationUnit unit) {
        unit.addImport("javax.persistence.Entity");
        unit.addImport("javax.persistence.Table");
        unit.addImport("javax.persistence.Column");
    }

    private void generator() {
        getDataFromSDL(sdl);
        // Get the VirtualMachine implementation.
        this.vm = VirtualMachine.getVirtualMachine();

        // Instantiate a new CompilationUnit.  The argument to the
        // compilation unit is the "codebase" or directory where the
        // compilation unit should be written.
        //
        // Make a new compilation unit rooted to the given sourcepath.
        CompilationUnit unit = vm.newCompilationUnit(System.getProperty("user.dir").concat("\\src\\main\\java"));

        setImportClasses(unit);
        // Set the package namespace.
        unit.setNamespace(TACO_DB_ENTITY);

        // Make a new class.

        this.cls = setClassName(unit, table.getTableName());

        cls.addAnnotation("Entity");
        cls.addAnnotation("Table(name =\"".concat(tableName).concat("\")"));
        // Make it a public class.
        cls.setAccess(Access.PUBLIC);

        generateVariables(table);

        generateGetters();
        generateSetters();
        // Make a new Method in the Class having type VOID and name "main".

//        ClassMethod method = cls.newMethod(vm.newType(Type.VOID), "main");
//        // Make it a public method.
//        method.setAccess(Access.PUBLIC);
//        // Make it a static method
//        method.isStatic(true);
//        // Add the "String[] argv" formal parameter.
//        method.addParameter(vm.newArray("String", 1), "argv");
//
//        // Create a new Method Invocation expression.
//        Invoke println = vm.newInvoke("System.out", "println");
//        // Add the Hello World string literal as the sole argument.
//        println.addArg(vm.newString("Hello World!"));
//        // Add this expression to the method in a statement.
//        method.newStmt(println);
        // Write the java file.
        unit.encode();
    }




    private void generateVariables(Table table) {
        List<Field> fColumns = table.getColumns();
        for (Field f : fColumns) {
            generateVariables(f.getType(), f.getName());
        }
    }

    private void generateGetters() {
        List<Field> fColumns = table.getColumns();
        for (Field f : fColumns) {
            ClassMethod m1 = this.cls.newMethod(getType(f),  capitalizeVar("get_"+f.getName()));
            m1.setAccess(Access.PUBLIC);
            m1.newReturn().setExpression(this.vm.newVar("this." + capitalizeVar(f.getName())));
        }
    }

    private void generateSetters() {
        List<Field> fColumns = table.getColumns();
        for (Field f : fColumns) {
            ClassMethod m = this.cls.newMethod(vm.newType(Type.VOID),  capitalizeVar("set_"+f.getName()));
            m.setAccess(Access.PUBLIC);
            m.addParameter(getType(f),"value");
            m.newStmt(this.vm.newAssign(this.vm.newVar("this." + capitalizeVar(f.getName())), this.vm.newVar("value")));
        }
    }


    private Type getType(Field filed){
        Type type ;
        if(filed.getType().equals(io.taco.metadata.enums.Type.Integer)){
            type = vm.newType(Type.INT);
        }else {
            type = vm.newType("String");
        }
        return type;
    }

    private void generateVariables(io.taco.metadata.enums.Type type, String name) {
        name = capitalizeVar(name);
        ClassField field = null;
        if (type.equals(io.taco.metadata.enums.Type.Integer)) {
            field = this.cls.newField(vm.newType(Type.INT), name);
        } else if (type.equals(io.taco.metadata.enums.Type.String)) {
            field = this.cls.newField(vm.newType("String"), name);
        }
        if(field !=null) {
            field.setAccess(Access.PRIVATE);
        }
    }

    private String capitalizeVar(String name) {
        String result;
        String[] names = name.split("_");
        result = names[0].toLowerCase();
        for (int i = 1; i < names.length; i++) {
            result = result + capitalize(names[i]);
        }
        return result;
    }

    private String capitalize(String s) {
        char[] chars = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
    }

    private PackageClass setClassName(CompilationUnit unit, String name) {
        return unit.newClass(name);
    }

    public static void main(String[] args) {
        new TestCG().generator();
    }

}
