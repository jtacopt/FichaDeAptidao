package io.taco.sql;

public class GroupBy {
}
