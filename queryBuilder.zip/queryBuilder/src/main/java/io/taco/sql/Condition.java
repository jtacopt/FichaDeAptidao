package io.taco.sql;

import io.taco.metadata.Field;
import io.taco.metadata.enums.Type;

public class Condition {

    Field field1 ;

    Field field2;
    String value;

    public Condition(Field field1, Field field2) {
        this.field1 = field1;
        this.field2 = field2;
    }

    public Condition(Field field1, String value) {
        this.field1 = field1;
        this.value = value;
    }

    @Override
    public String toString() {
        String qResult = field1.getName().concat("=");
        if(field2 == null){
            if(field1.getType().equals(Type.Integer)) {
                qResult  = qResult.concat(value).concat("\n");
            }else {
                qResult = qResult.concat("'").concat(value).concat("'\n");
            }
        }else {
            qResult = qResult.concat(field2.getName()).concat("\n");
        }
        return qResult;
    }
}
