package io.taco.sql;

import entities.*;

public class QueryMetamorph {

    private Select select;

    private From from ;

    private Where where;

    private Join join;

    private OrderBy orderBy;

    public Select getSelect() {
        return select;
    }

    public void setSelect(Select select) {
        this.select = select;
    }

    public From getFrom() {
        return from;
    }

    public void setFrom(From from) {
        this.from = from;
    }

    public Where getWhere() {
        return where;
    }

    public void setWhere(Where where) {
        this.where = where;
    }


    public void setJoin(Join join) {
        this.join = join;
    }

    public void setOrderBy(OrderBy orderBy){
        this.orderBy = orderBy;
    }

    public OrderBy getOrderBy() {
        return orderBy;
    }

    public String getQuery() {
        String query ;
        String qSelect = getSelect().toString();
        String qFrom = getFrom().toString();
        query = qSelect.concat(qFrom);
        if(getWhere() != null){
            query = query.concat(getWhere().toString());
            if(getWhere().qAnd != null){
                query = query.concat(getWhere().qAnd.toString());
                And mainAnd = getWhere().qAnd;
                if(!getWhere().qAnd.ands.isEmpty()){
                    for(And and: mainAnd.ands){
                        query = query.concat(and.toString());
                    }
                }
            }
        }
        if(getOrderBy() != null){
            query = query.concat(getOrderBy().toString());
        }
        return query;
    }
}
