package io.taco.sql;

import entities.ElTaco;
import entities.OrderBy;

import java.util.ArrayList;
import java.util.List;

public class And {

    private static final String SQL_AND = "AND ";

    private Condition qCondition ;

    public List<And> ands;

    public And(Condition condition) {
        ands = new ArrayList<>();
        this.qCondition=condition;
    }

    public And and (Condition condition){
        And and = new And(condition);
        ElTaco.queryMetamorph.getWhere().qAnd.ands.add(and);
        return and;
    }
    @Override
    public String toString() {
        return SQL_AND + qCondition.toString();
    }

    public OrderBy orderBy () {
        OrderBy orderBy = new OrderBy();
        ElTaco.queryMetamorph.setOrderBy(orderBy);
        return orderBy;
    }
}
