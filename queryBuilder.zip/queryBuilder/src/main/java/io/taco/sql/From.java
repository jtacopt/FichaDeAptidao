package io.taco.sql;

import entities.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public class From {

    private String table;

    public From(Object object) {
        retrieveTableName (object);
    }

    private void retrieveTableName(Object object) {
        List<Method> methods = Arrays.asList(object.getClass().getMethods());
        Method method = methods.stream().filter(x->x.getName().equals("getTable")).findAny().get();
        try {
            this.table = (String) method.invoke(object);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public Join join (String table){
        Join join = new Join(table);
        ElTaco.queryMetamorph.setJoin(join);
        return join;
    }


    public OrderBy orderBy () {
        OrderBy orderBy = new OrderBy();
        ElTaco.queryMetamorph.setOrderBy(orderBy);
        return orderBy;
    }

    public String getQuery(){
        return ElTaco.queryMetamorph.getQuery();
    }

    @Override
    public String toString() {
        return "FROM ".concat(getTable()).concat("\n");
    }

    public Where where(Condition condition) {
        Where where = new Where(condition);
        ElTaco.queryMetamorph.setWhere(where);
        return where;
    }


}
