package io.taco.metadata;

import io.taco.sql.Condition;
import io.taco.metadata.enums.Type;

public class Field {

    private String name ;
    private Type type ;


    public Field(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    /*
     *  Operators
     */

    // Equal
    public Condition equal(Field field){
        Condition condition = new Condition(this,field);
        return condition;
    }

    public Condition equal(String value) {
        return new Condition(this,value);
    }

    //Greater Than
    public Condition greaterThan () {
        return null;
    }

    public Condition lessThan () {
        return null;
    }


    public Condition lessThanOrEqual () {
        return null;
    }

    public Condition notEqual () {
        return null;
    }

    public  Condition between (String x1 ,String X2){
        return null;
    }
}
