package io.taco.metadata;

import java.util.ArrayList;
import java.util.List;

public class Table {

private String tableName;
private List<Field> columns ;

    public Table() {
        columns = new ArrayList<>();
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<Field> getColumns() {
        return columns;
    }

    public void setColumns(List<Field> columns) {
        this.columns = columns;
    }
}
