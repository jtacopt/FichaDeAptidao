import entities.ElTaco;
import sombrero.Author;


public class Test {

    public static void main(String[] args) {

        System.out.println(new ElTaco().select("g").from(Author.AUTHOR).where(Author.FIRST_NAME.equal(Author.FIRST_NAME)).getQuery());
    }
}
