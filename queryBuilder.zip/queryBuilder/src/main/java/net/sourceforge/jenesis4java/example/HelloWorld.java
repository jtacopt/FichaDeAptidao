/**
 * The HelloWorld example class.
 */
package net.sourceforge.jenesis4java.example;

import java.io.Serializable;

public class HelloWorld extends Object implements Serializable {
    
    public static void main(String[] argv)
    {
        System.out.println("Hello World!");
    }
}
