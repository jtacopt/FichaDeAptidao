package sombrero;

import io.taco.metadata.Field;
import io.taco.metadata.enums.Type;

public class Author {

    public static final entities.Author AUTHOR = new entities.Author();

    public static final Field FIRST_NAME = new Field("first_name", Type.String);
}
