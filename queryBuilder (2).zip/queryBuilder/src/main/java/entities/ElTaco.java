package entities;

import io.taco.sql.Function.AggregateFunction;
import io.taco.sql.QueryMetamorph;
import io.taco.sql.SelectCondition;


public class ElTaco {

    private static QueryMetamorph queryMetamorph;

    public static ElTaco build() {
        return new ElTaco();
    }

    public static ElTaco gen() {
        queryMetamorph = new QueryMetamorph();
        return new ElTaco();
    }

    public SelectCondition select () {
        queryMetamorph.setSelect("SELECT * ");
        return new SelectCondition(queryMetamorph);
    }

    public static AggregateFunction min (){
        return new AggregateFunction();
    }

}
