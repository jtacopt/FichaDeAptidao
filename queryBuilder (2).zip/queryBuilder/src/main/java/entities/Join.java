package entities;

public class Join {

    private String table;

    public Join(String table) {

    }
}
