import entities.ElTaco;
import io.taco.metadata.Field;
import io.taco.metadata.enums.Type;
import org.jooq.DSLContext;

import org.jooq.SQLDialect;
import org.jooq.generated.tables.Author;
import org.jooq.impl.DSL;

import java.sql.Connection;
import java.util.logging.FileHandler;

import static org.jooq.generated.tables.Author.AUTHOR;
import static org.jooq.impl.DSL.max;


public class Test {



    public static void main(String[] args) {
//        Connection con = null;
//        DSLContext create = DSL.using(con, SQLDialect.MYSQL);
//        String sql = create.select().from("x")
//                .where(AUTHOR.FIRST_NAME.equal("2"))
//                .and(AUTHOR.FIRST_NAME.notEqual("x"))
//                .and(AUTHOR.FIRST_NAME.notEqual("x"))
//                .and(AUTHOR.FIRST_NAME.notEqual("x"))
//                .or(AUTHOR.FIRST_NAME.notEqual("x"))
//                .and(AUTHOR.FIRST_NAME.plus(2).notEqual("0")
//                        .and(AUTHOR.FIRST_NAME.sub(2).notEqual("0"))
//                        .and(AUTHOR.FIRST_NAME.sub(2).notEqual("0")))
//                .getQuery().getSQL();

        Field x = new io.taco.metadata.Field("lol", Type.Integer);
        System.out.println(
                ElTaco.gen().select().from("Porco")
                .where( x.equal(x)
                                .or(x.plus(0)
                                        .equal(1)))
                .getQuery());


    }
}
