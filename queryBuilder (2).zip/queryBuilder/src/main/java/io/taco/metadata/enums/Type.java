package io.taco.metadata.enums;

public enum Type {
    Integer , String
}
