package io.taco.sql.enums.Operators.LogicalOperator;

public enum LogicalOperator {

    AND("AND"), OR("OR");

    private String logicalOperator;

    LogicalOperator(String logicalOperator) {
        setLogicalOperator(logicalOperator);
    }

    public String getLogicalOperator() {
        return logicalOperator;
    }

    private void setLogicalOperator(String logicalOperator) {
        this.logicalOperator = logicalOperator;
    }
}
