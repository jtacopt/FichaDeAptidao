package io.taco.sql;

import entities.*;

public class QueryMetamorph {

    private String select;

    private String from ;

    private String whereCondition;

    public String getQuery() {
        return getSelect() + getFrom() + getWhereCondition();
    }

    public String getSelect() {
        return select;
    }

    public void setSelect(String select) {
        this.select = select;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getWhereCondition() {
        return whereCondition;
    }

    public void setWhereCondition(String whereCondition) {
        this.whereCondition = whereCondition;
    }
}
