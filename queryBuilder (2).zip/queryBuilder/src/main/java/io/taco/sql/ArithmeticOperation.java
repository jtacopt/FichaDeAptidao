package io.taco.sql;

import io.taco.metadata.Field;
import io.taco.sql.enums.Operators.ArithmeticOperator.ArithmeticOperator;
import io.taco.sql.enums.Operators.ComparisonOperator.ComparisonOperator;

public class ArithmeticOperation {

    private Field field;
    private ArithmeticOperator operator;
    private Integer value ;

    public ArithmeticOperation(Field field, ArithmeticOperator operator, int value) {
        setField(field);
        setOperator(operator);
        setValue(value);
    }

    public Condition equal(Integer integer) {
        return new Condition(ComparisonOperator.EQUAL_TO, this, integer);
    }

    public ArithmeticOperator getOperator() {
        return operator;
    }

    public void setOperator(ArithmeticOperator operator) {
        this.operator = operator;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    @Override
    public String toString() {
        return "(".concat(field.getName()).concat(getOperator().getArithmeticOperator()).concat(String.valueOf(getValue())).concat(")");
    }
}
