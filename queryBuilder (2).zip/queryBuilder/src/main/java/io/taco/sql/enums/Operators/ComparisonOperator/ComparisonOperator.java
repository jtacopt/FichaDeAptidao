package io.taco.sql.enums.Operators.ComparisonOperator;

public enum ComparisonOperator {

    EQUAL_TO("="), GREATER_THAN(">"), LESS_THAN(">"), GREATER_THAN_OR_EQUAL_TO(">="), LESS_THAN_OR_EQUAL_TO("<="), NOT_EQUAL("<>"), IN("IN"), NOT_IN("NOT IN"), LIKE("LIKE"), NOT_LIKE("NOT LIKE"), BETWEEN("BETWEEN");

    private String comparisonOperator;

    ComparisonOperator(String comparisonOperator) {
        setComparisonOperator(comparisonOperator);
    }

    public String getComparisonOperator() {
        return comparisonOperator;
    }

    public void setComparisonOperator(String comparisonOperator) {
        this.comparisonOperator = comparisonOperator;
    }
}
