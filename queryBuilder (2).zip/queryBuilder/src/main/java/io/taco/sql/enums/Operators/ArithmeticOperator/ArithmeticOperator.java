package io.taco.sql.enums.Operators.ArithmeticOperator;

public enum ArithmeticOperator {

    ADD("+"), SUBTRACT("-"),MULTIPLY("*"),DIVIDE("/");

    private String arithmeticOperator;

    ArithmeticOperator(String arithmeticOperator) {
        setArithmeticOperator(arithmeticOperator);
    }

    public String getArithmeticOperator() {
        return arithmeticOperator;
    }

    private void setArithmeticOperator(String arithmeticOperator) {
        this.arithmeticOperator = arithmeticOperator;
    }
}
