package io.taco.sql.Function;

public class AggregateFunction {


}
