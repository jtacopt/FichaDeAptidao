package io.taco.sql.where;

public class In {
}
