package io.taco.sql;


import io.taco.metadata.Field;
import io.taco.sql.enums.Operators.ComparisonOperator.ComparisonOperator;

public class Condition {

    private QueryMetamorph queryMetamorph;

    private ComparisonOperator operatorType;

    public String fCondition ;

    private Field field1 ;
    private ArithmeticOperation arithmeticOperation;

    private Field field2 ;
    private Integer integer;

    public Condition(ComparisonOperator comparisonOperator, Field field1, Field field2) {
        setOperatorType(comparisonOperator);
        setField1(field1);
        setField2(field2);
    }

    public Condition(ComparisonOperator comparisonOperator, ArithmeticOperation arithmeticOperation, Integer integer) {
        setOperatorType(comparisonOperator);
        setArithmeticOperation(arithmeticOperation);
        setInteger(integer);

    }

    public Field getField1() {
        return field1;
    }

    public void setField1(Field field1) {
        this.field1 = field1;
    }

    public Field getField2() {
        return field2;
    }

    public void setField2(Field field2) {
        this.field2 = field2;
    }

    public Condition  and (){
        return this;
    }

    public Condition or (Condition condition){
        fCondition = "(".concat(this.toString()).concat(" OR ").concat(condition.toString()).concat(")");
        return this;
    }

    public ComparisonOperator getOperatorType() {
        return operatorType;
    }

    public void setOperatorType(ComparisonOperator operatorType) {
        this.operatorType = operatorType;
    }

    public ArithmeticOperation getArithmeticOperation() {
        return arithmeticOperation;
    }

    public void setArithmeticOperation(ArithmeticOperation arithmeticOperation) {
        this.arithmeticOperation = arithmeticOperation;
    }

    public Integer getInteger() {
        return integer;
    }

    public void setInteger(Integer integer) {
        this.integer = integer;
    }

    @Override
    public String toString() {
        if(fCondition != null)
            return fCondition;
       return getCondition();
    }

    private String getCondition(){
        if(getField1() != null && getField2() !=null){
            return getFieldsCondition();
        }
        if(getArithmeticOperation() !=null && getInteger() !=null){
            return getArithmeticCondition ();
        }
        return null;
    }

    private String getArithmeticCondition() {
        return getArithmeticOperation().toString().concat(getOperatorType().getComparisonOperator()).concat(String.valueOf(getInteger()));
    }

    private String getFieldsCondition() {
        return getField1().getName().concat(getOperatorType().getComparisonOperator()).concat(getField2().getName());
    }

}
