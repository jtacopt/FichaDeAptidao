package io.taco.sql;

public class SelectCondition {

    private QueryMetamorph queryMetamorph ;

    public SelectCondition(QueryMetamorph queryMetamorph) {
        setQueryMetamorph(queryMetamorph);
    }

    public SelectCondition select(){
        return this;
    }

    public SelectCondition from(String string){
        getQueryMetamorph().setFrom(string + "\n");
        return this;
    }

    public SelectCondition where (Condition condition){
        getQueryMetamorph().setWhereCondition(condition.toString());
        return this;
    }

    public SelectCondition and (Condition condition){
        return this;
    }

    public SelectCondition or (Condition condition){
        return this;
    }


    public String getQuery() {
        return getQueryMetamorph().getQuery();
    }

    public QueryMetamorph getQueryMetamorph() {
        return queryMetamorph;
    }

    public void setQueryMetamorph(QueryMetamorph queryMetamorph) {
        this.queryMetamorph = queryMetamorph;
    }

}
