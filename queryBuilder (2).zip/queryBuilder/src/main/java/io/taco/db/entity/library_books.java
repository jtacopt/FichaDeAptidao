package io.taco.db.entity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name ="author")
public class library_books {
    
    public String getAuthor()
    {
        return this.author;
    }

    public String getCopyrightDate()
    {
        return this.copyrightDate;
    }

    public String getIsbn()
    {
        return this.isbn;
    }

    public String getTitle()
    {
        return this.title;
    }

    public void setAuthor(String value)
    {
        this.author = value;
    }

    public void setCopyrightDate(String value)
    {
        this.copyrightDate = value;
    }

    public void setIsbn(String value)
    {
        this.isbn = value;
    }

    public void setTitle(String value)
    {
        this.title = value;
    }

    private String author;

    private String copyrightDate;

    private String isbn;

    private String title;
}